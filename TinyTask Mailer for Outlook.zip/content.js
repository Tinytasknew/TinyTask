function extractEmail(text) {

    const match =
        String(text || "").match(
            /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i
        );

    return match
        ? match[0]
        : null;
}

function getEmailFromElement(element) {

    if (!element) {
        return null;
    }

    const fragments = [
        element.getAttribute("aria-label"),
        element.getAttribute("title"),
        element.getAttribute("data-auth"),
        element.getAttribute("data-email"),
        element.getAttribute("data-user-email"),
        element.textContent
    ].filter(Boolean);

    return extractEmail(
        fragments.join(" ")
    );
}

function getCurrentOutlookAccount() {

    const trustedSelectors = [
        'button[aria-label*="Account manager"]',
        'button[aria-label*="account manager"]',
        'button[aria-label*="Microsoft account"]',
        'button[aria-label*="Microsoft Account"]',
        'button[aria-label*="profile"]',
        'button[aria-label*="Profile"]',
        '[role="button"][aria-label*="Account manager"]',
        '[role="button"][aria-label*="Microsoft account"]',
        'button[data-testid="me-control"]',
        '#O365_MainLink_Me',
        '[id*="meInitials"]',
        '[id*="personaButton"]',
        '[id*="profileButton"]',
        '[aria-label*="Signed in as"]'
    ];

    for (const selector of trustedSelectors) {

        const elements =
            document.querySelectorAll(selector);

        for (const element of elements) {

            const email =
                getEmailFromElement(
                    element
                );

            if (email) {
                return email;
            }
        }
    }

    const scopedFallbacks = [
        'header button[title*="@"]',
        'header [role="button"][title*="@"]',
        'aside button[title*="@"]',
        'nav button[title*="@"]',
        '[role="navigation"] button[title*="@"]',
        '[role="navigation"] [aria-label*="@hotmail"]',
        '[role="navigation"] [aria-label*="@outlook"]',
        '[role="navigation"] [aria-label*="@live"]'
    ];

    for (const selector of scopedFallbacks) {

        const email =
            getEmailFromElement(
                document.querySelector(selector)
            );

        if (email) {
            return email;
        }
    }

    const visibleCandidates =
        Array.from(
            document.querySelectorAll(
                "[aria-label*='@'], [title*='@'], [data-auth*='@'], [data-email*='@'], [data-user-email*='@'], nav *, aside *, header *, [role='navigation'] *"
            )
        )
            .map((element) => {

                const email =
                    getEmailFromElement(
                        element
                    );

                if (!email) {
                    return null;
                }

                const rect =
                    element.getBoundingClientRect();

                if (
                    rect.width <= 0 ||
                    rect.height <= 0
                ) {
                    return null;
                }

                let score = 0;

                if (
                    rect.left < window.innerWidth * 0.35
                ) {
                    score += 4;
                }

                if (
                    rect.top < window.innerHeight * 0.5
                ) {
                    score += 3;
                }

                if (
                    /@(hotmail|outlook|live)\./i.test(email)
                ) {
                    score += 12;
                }

                if (
                    element.closest("nav, aside, [role='navigation']")
                ) {
                    score += 5;
                }

                if (
                    element.closest("header")
                ) {
                    score += 4;
                }

                if (
                    element.closest("main, [role='main'], article")
                ) {
                    score -= 12;
                }

                return {
                    email,
                    score
                };
            })
            .filter(Boolean)
            .sort(
                (a, b) =>
                    b.score - a.score
            );

    const preferredAccount =
        visibleCandidates.find(
            (candidate) =>
                /@(hotmail|outlook|live)\./i.test(
                    candidate.email
                )
        );

    if (preferredAccount) {
        return preferredAccount.email;
    }

    return null;
}

function showMailerOverlay(message) {

    let overlay =
        document.getElementById("ttmOverlay");

    if (!overlay) {

        overlay =
            document.createElement("div");

        overlay.id =
            "ttmOverlay";

        overlay.style.cssText =
            "position:fixed;top:20px;right:20px;z-index:999999;background:#111;color:#fff;padding:16px 20px;border-radius:12px;font-size:14px;font-family:Arial;min-width:240px;box-shadow:0 6px 20px rgba(0,0,0,.45);border:1px solid #333;";

        document.body.appendChild(overlay);
    }

    overlay.innerHTML =
        "<div style='display:flex;justify-content:space-between;align-items:center;font-weight:bold'><span>TinyTask Mailer for Outlook</span><span id='ttmClose' style='cursor:pointer'>[X]</span></div><hr style='margin:6px 0;border-color:#333'>Status: " + message;

    const closeBtn =
        document.getElementById("ttmClose");

    if (closeBtn) {
        closeBtn.onclick = () => {
            overlay.remove();
        };
    }
}

function sleep(ms) {

    return new Promise(
        (resolve) => setTimeout(resolve, ms)
    );
}

function findVisibleElement(selectors) {

    for (const selector of selectors) {

        const elements =
            document.querySelectorAll(selector);

        for (const element of elements) {

            if (
                element &&
                element.offsetParent !== null
            ) {
                return element;
            }
        }
    }

    return null;
}

function openComposeWindow() {

    const composeButton =
        findVisibleElement([
            'button[aria-label*="New mail"]',
            'div[role="button"][aria-label*="New mail"]',
            'button[title*="New mail"]',
            'button[aria-label*="New message"]',
            'div[role="button"][aria-label*="New message"]'
        ]);

    if (composeButton) {
        composeButton.click();
        return true;
    }

    return false;
}

function getComposeFields() {

    return {
        toField:
            findVisibleElement([
                'input[aria-label="To"]',
                'input[placeholder="To"]',
                'div[aria-label="To"] input',
                'div[role="textbox"][aria-label="To"]',
                'div[contenteditable="true"][aria-label="To"]'
            ]),
        subjectField:
            findVisibleElement([
                'input[aria-label*="subject"]',
                'input[placeholder*="subject"]',
                'input[placeholder*="Subject"]',
                'input[aria-label*="Add a subject"]'
            ]),
        bodyField:
            findVisibleElement([
                'div[role="textbox"][aria-label*="Message body"]',
                'div[contenteditable="true"][aria-label*="Message body"]',
                'div[contenteditable="true"][data-tabster*="editor"]'
            ])
    };
}

async function waitForComposeFields(timeoutMs = 30000) {

    const startTime =
        Date.now();

    let composeOpened =
        false;

    while (Date.now() - startTime < timeoutMs) {

        if (document.readyState === "loading") {
            await sleep(300);
            continue;
        }

        const composeFields =
            getComposeFields();

        if (
            composeFields.toField &&
            composeFields.subjectField &&
            composeFields.bodyField
        ) {
            return composeFields;
        }

        if (!composeOpened) {
            composeOpened =
                openComposeWindow();
        }

        await sleep(500);
    }

    return getComposeFields();
}

function dispatchInputEvents(element) {

    element.dispatchEvent(
        new Event("input", {
            bubbles: true
        })
    );

    element.dispatchEvent(
        new Event("change", {
            bubbles: true
        })
    );
}

function setEditableValue(element, value) {

    const safeValue =
        value === undefined ||
        value === null
            ? ""
            : String(value);

    element.focus();

    if (
        element.matches("input, textarea")
    ) {

        const descriptor =
            Object.getOwnPropertyDescriptor(
                Object.getPrototypeOf(element),
                "value"
            );

        if (
            descriptor &&
            typeof descriptor.set === "function"
        ) {
            descriptor.set.call(
                element,
                safeValue
            );
        } else {
            element.value = safeValue;
        }

        dispatchInputEvents(element);
        return;
    }

    element.textContent =
        safeValue;

    dispatchInputEvents(element);
}

function setBodyContent(bodyField, message) {

    const safeMessage =
        message === undefined ||
        message === null
            ? ""
            : String(message);

    bodyField.focus();
    bodyField.innerHTML = "";

    const lines =
        safeMessage.split(/\r?\n/);

    if (lines.length === 0) {
        lines.push("");
    }

    lines.forEach((line) => {

        const block =
            document.createElement("div");

        block.textContent =
            line || "\u00A0";

        bodyField.appendChild(block);
    });

    dispatchInputEvents(bodyField);
}

function commitRecipientField(field) {

    field.dispatchEvent(
        new KeyboardEvent("keydown", {
            key: "Enter",
            code: "Enter",
            bubbles: true
        })
    );

    field.dispatchEvent(
        new KeyboardEvent("keyup", {
            key: "Enter",
            code: "Enter",
            bubbles: true
        })
    );
}

function findSendButton() {

    return findVisibleElement([
        'button[aria-label*="Send"]',
        'button[title*="Send"]',
        'div[role="button"][aria-label*="Send"]',
        'span[title*="Send"]'
    ]);
}

chrome.runtime.onMessage.addListener(
    (request, sender, sendResponse) => {

        if (
            request.action ===
            "getOutlookAccount"
        ) {

            sendResponse({
                gmail:
                    getCurrentOutlookAccount()
            });
        }

        if (
            request.action ===
            "campaignStopped"
        ) {
            showMailerOverlay(
                "Campaign Stopped"
            );
        }

        if (
            request.action ===
            "updateOverlayStatus"
        ) {
            showMailerOverlay(
                request.message ||
                "Running..."
            );
        }

        if (
            request.action ===
            "openCompose"
        ) {
            openComposeWindow();
        }

        if (
            request.action ===
            "fillLead"
        ) {

            const lead =
                request.lead || {};

            showMailerOverlay(
                "Waiting for Outlook..."
            );

            (async () => {

                const {
                    toField,
                    subjectField,
                    bodyField
                } =
                    await waitForComposeFields();

                if (
                    !toField ||
                    !subjectField ||
                    !bodyField
                ) {

                    showMailerOverlay(
                        "Outlook Still Loading"
                    );

                    chrome.runtime.sendMessage({
                        action:
                            "emailFailed",
                        reason:
                            "Compose fields not ready"
                    });

                    return;
                }

                setEditableValue(
                    toField,
                    lead.email || ""
                );

                commitRecipientField(
                    toField
                );

                await sleep(500);

                setEditableValue(
                    subjectField,
                    lead.subject || ""
                );

                await sleep(300);

                setBodyContent(
                    bodyField,
                    lead.message || ""
                );

                showMailerOverlay(
                    "Draft Ready"
                );

                setTimeout(() => {

                    chrome.storage.local.get(
                        ["running"],
                        (state) => {

                            if (
                                state.running !== true
                            ) {

                                showMailerOverlay(
                                    "Campaign Stopped"
                                );

                                return;
                            }

                            const sendBtn =
                                findSendButton();

                            if (sendBtn) {

                                showMailerOverlay(
                                    "Sending Email..."
                                );

                                sendBtn.click();

                                chrome.runtime.sendMessage({
                                    action:
                                        "emailSent"
                                });
                            } else {
                                chrome.runtime.sendMessage({
                                    action:
                                        "emailFailed",
                                    reason:
                                        "Send button not found"
                                });
                            }
                        }
                    );
                }, 3000);
            })();
        }
    }
);
