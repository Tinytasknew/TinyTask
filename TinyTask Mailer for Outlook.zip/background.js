importScripts(
    chrome.runtime.getURL(
        "lib/papaparse.min.js"
    )
);

let overlayCountdownTimer =
    null;

const MACHINE_ID_STORAGE_KEY =
    "ttm_profile_machine_id";

const outlookHosts = [
    "outlook.office.com",
    "outlook.live.com",
    "outlook.office365.com"
];

function createProfileMachineId() {

    if (
        typeof crypto !== "undefined" &&
        typeof crypto.randomUUID === "function"
    ) {
        return crypto.randomUUID();
    }

    return "ttm-profile-" + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function getStoredMachineId() {

    return new Promise(
        (resolve) => {
            chrome.storage.local.get(
                MACHINE_ID_STORAGE_KEY,
                (result) => {
                    resolve(
                        String(
                            result[
                                MACHINE_ID_STORAGE_KEY
                            ] || ""
                        ).trim()
                    );
                }
            );
        }
    );
}

async function getOrCreateMachineId() {

    const existingMachineId =
        await getStoredMachineId();

    if (existingMachineId) {
        return existingMachineId;
    }

    const newMachineId =
        createProfileMachineId();

    await chrome.storage.local.set({
        [MACHINE_ID_STORAGE_KEY]:
            newMachineId
    });

    return newMachineId;
}

function isOutlookUrl(url) {

    return outlookHosts.some(
        (host) =>
            String(url || "").includes(host)
    );
}

async function findExistingOutlookTab() {

    const tabs =
        await chrome.tabs.query({});

    const preferredTab =
        tabs.find(
            (tab) =>
                isOutlookUrl(tab.url) &&
                tab.active === true
        );

    if (preferredTab) {
        return preferredTab;
    }

    return tabs.find(
        (tab) => isOutlookUrl(tab.url)
    ) || null;
}

function clearOverlayCountdown() {

    if (!overlayCountdownTimer) {
        return;
    }

    clearInterval(
        overlayCountdownTimer
    );

    overlayCountdownTimer =
        null;
}

function sendOverlayStatus(
    tabId,
    message
) {

    if (!tabId) {
        return;
    }

    chrome.tabs.sendMessage(
        tabId,
        {
            action:
                "updateOverlayStatus",
            message:
                message
        },
        () => {
            void chrome.runtime.lastError;
        }
    );
}

function showOverlayForTab(
    tabId,
    message
) {

    sendOverlayStatus(
        tabId,
        message
    );
}

function showOverlayForStoredOutlookTab(
    message
) {

    chrome.storage.local.get(
        ["outlookTabId"],
        ({ outlookTabId }) => {
            showOverlayForTab(
                outlookTabId,
                message
            );
        }
    );
}

function sendMessageToTab(
    tabId,
    payload,
    callback
) {

    if (!tabId) {
        return;
    }

    chrome.tabs.sendMessage(
        tabId,
        payload,
        (response) => {

            if (chrome.runtime.lastError) {
                console.log(
                    "Tab message skipped:",
                    chrome.runtime.lastError.message
                );
                return;
            }

            if (typeof callback === "function") {
                callback(response);
            }
        }
    );
}

function startOverlayCountdown(
    tabId,
    delaySeconds
) {

    clearOverlayCountdown();

    let remaining =
        delaySeconds;

    sendOverlayStatus(
        tabId,
        `Waiting ${remaining} seconds...`
    );

    overlayCountdownTimer =
        setInterval(() => {

            remaining -= 1;

            if (remaining <= 0) {
                clearOverlayCountdown();
                return;
            }

            sendOverlayStatus(
                tabId,
                `Waiting ${remaining} seconds...`
            );

        }, 1000);
}

async function canSendFromServer(
    licenseKey,
    gmail
) {

    if (!licenseKey || !gmail) {
        return null;
    }

    try {

        const response = await fetch(
            "https://license.tinytask.org/api/can-send-outlook",
            {
                method: "POST",
                headers: {
                    "Content-Type":
                        "application/json"
                },
                body: JSON.stringify({
                    license_key:
                        licenseKey,
                    outlook_account:
                        gmail
                })
            }
        );

        return await response.json();

    } catch (error) {

        console.error(
            "Server Check Error",
            error
        );

        return null;
    }
}

async function logEmailToServer(
    licenseKey,
    gmail
) {

    if (!licenseKey || !gmail) {
        return null;
    }

    try {

        const response = await fetch(
            "https://license.tinytask.org/api/send-outlook-log",
            {
                method: "POST",
                headers: {
                    "Content-Type":
                        "application/json"
                },
                body: JSON.stringify({
                    license_key:
                        licenseKey,
                    outlook_account:
                        gmail
                })
            }
        );

        return await response.json();

    } catch (error) {

        console.error(
            "Server Quota Error",
            error
        );

        return null;
    }
}

async function validateOutlookLicenseForServer(
    licenseKey
) {

    if (!licenseKey) {
        return false;
    }

    try {

        const machineId =
            await getOrCreateMachineId();

        const response = await fetch(
            "https://license.tinytask.org/api/validate",
            {
                method: "POST",
                headers: {
                    "Content-Type":
                        "application/json"
                },
                body: JSON.stringify({
                    license_key:
                        licenseKey,
                    machine_id:
                        machineId,
                    legacy_machine_id:
                        navigator.userAgent,
                    product_type:
                        "OUTLOOK"
                })
            }
        );

        const result =
            await response.json();

        return result.valid === true;

    } catch (error) {

        console.error(
            "Outlook License Validation Error",
            error
        );

        return false;
    }
}

function persistQuotaSnapshot(
    gmail,
    quota
) {

    if (!gmail || !quota) {
        return;
    }

    chrome.storage.local.set({
        lastKnownGmail:
            gmail,
        lastQuotaState: {
            ...quota,
            gmail_account:
                gmail,
            updated_at:
                Date.now()
        }
    });
}

function getFirstName(name) {

    const trimmedName =
        (name || "").trim();

    if (!trimmedName) {
        return "";
    }

    return trimmedName.split(/\s+/)[0];
}

function buildMessageWithGreeting(name, message) {

    const firstName =
        getFirstName(name);

    const originalMessage =
        message === undefined ||
        message === null
            ? ""
            : String(message);

    if (!firstName) {
        return originalMessage;
    }

    return `Hi ${firstName},\n\n${originalMessage}`;
}

function prepareLead(lead) {

    const safeLead =
        lead || {};

    return {

        name:
            safeLead.name || "",

        email:
            safeLead.email || "",

        subject:
            safeLead.subject || "",

        message:
            buildMessageWithGreeting(
                safeLead.name,
                safeLead.message
            )

    };
}

function leadFromRow(row) {

    return prepareLead({

        name:
            row[0] === undefined ||
            row[0] === null
                ? ""
                : String(row[0]),

        email:
            row[1] === undefined ||
            row[1] === null
                ? ""
                : String(row[1]),

        subject:
            row[2] === undefined ||
            row[2] === null
                ? ""
                : String(row[2]),

        message:
            row[3] === undefined ||
            row[3] === null
                ? ""
                : String(row[3])

    });
}

function parseCampaignRows(csv) {

    return Papa.parse(
        csv || "",
        {
            skipEmptyLines: true
        }
    ).data;
}

function isHtmlResponse(text) {

    return /<!DOCTYPE html|<html/i.test(
        text || ""
    );
}

async function loadSheetCsvFromGoogle(
    csvUrl
) {

    const response =
        await fetch(
            csvUrl,
            {
                credentials:
                    "include",
                redirect:
                    "follow"
            }
        );

    if (
        response.redirected &&
        response.url.includes(
            "accounts.google.com"
        )
    ) {
        throw new Error(
            "Google Sheet access requires a signed-in Google account with permission to view the sheet."
        );
    }

    if (!response.ok) {
        throw new Error(
            "Unable to download Google Sheet."
        );
    }

    const csv =
        await response.text();

    if (isHtmlResponse(csv)) {
        throw new Error(
            "Google returned a sign-in page instead of sheet data. Please make sure the active Chrome Google account can open this sheet."
        );
    }

    return csv;
}

function updateStoredSheetStatus(rowIndex, status) {

    chrome.storage.local.get(
        [
            "campaignCsv",
            "campaignLeads",
            "statusColumnIndex"
        ],
        (result) => {

            const statusColumnIndex =
                result.statusColumnIndex;

            if (
                statusColumnIndex === undefined ||
                statusColumnIndex < 0
            ) {
                return;
            }

            const rows =
                result.campaignLeads ||
                parseCampaignRows(
                    result.campaignCsv
                );

            if (
                !rows ||
                !rows[rowIndex]
            ) {
                return;
            }

            rows[rowIndex][statusColumnIndex] =
                status;

            chrome.storage.local.set({
                campaignLeads: rows,
                campaignCsv:
                    Papa.unparse(rows)
            });

        }
    );
}

function syncCampaignToLocalState(campaign, statusOverride) {

    if (!campaign) {
        return;
    }

    const status =
        statusOverride ||
        campaign.status ||
        "Ready";

    chrome.storage.local.set({
        campaign: {
            ...campaign,
            status: status
        }
    });
}

function stopCampaignForQuota(campaign) {

    if (!campaign) {
        return;
    }

    campaign.status =
        "Quota Reached - Switch Outlook";

    syncCampaignToLocalState(
        campaign,
        "Quota Reached - Switch Outlook"
    );

    chrome.storage.local.set({
        running: false
    });

    showOverlayForStoredOutlookTab(
        "Quota Reached - Switch Outlook"
    );

    clearOverlayCountdown();
}

chrome.runtime.onMessage.addListener(
    (
        request,
        sender,
        sendResponse
    ) => {

        if (
            request.action ===
            "loadSheetCsv"
        ) {

            (async () => {

                try {

                    const csv =
                        await loadSheetCsvFromGoogle(
                            request.csvUrl
                        );

                    sendResponse({
                        success:
                            true,
                        csv: csv
                    });

                } catch (error) {

                    sendResponse({
                        success:
                            false,
                        error:
                            error.message ||
                            "Unable to load sheet"
                    });
                }

            })();

            return true;
        }

        if (
            request.action ===
            "openOutlookCompose"
        ) {
            (async () => {

                const authData =
                    await new Promise(
                        (resolve) => {
                            chrome.storage.local.get(
                                ["licenseKey"],
                                resolve
                            );
                        }
                    );

                const hasValidLicense =
                    await validateOutlookLicenseForServer(
                        authData.licenseKey
                    );

                if (!hasValidLicense) {
                    chrome.storage.local.set({
                        running: false
                    });

                    console.log(
                        "Outlook start blocked: license required"
                    );

                    return;
                }

                const existingTab =
                    await findExistingOutlookTab();

                const startComposeFlow =
                    (tab) => {

                        if (!tab || !tab.id) {
                            return;
                        }

                        chrome.storage.local.set({
                            outlookTabId: tab.id
                        });

                        showOverlayForTab(
                            tab.id,
                            "Preparing Outlook..."
                        );

                        console.log(
                            "Outlook Tab Saved",
                            tab.id
                        );

                        setTimeout(() => {

                            sendMessageToTab(
                                tab.id,
                                {
                                    action:
                                        "openCompose"
                                }
                            );

                            showOverlayForTab(
                                tab.id,
                                "Opening compose..."
                            );

                        }, existingTab ? 2500 : 9000);

                        setTimeout(() => {

                            sendMessageToTab(
                                tab.id,
                                {
                                    action: "fillLead",
                                    lead:
                                        prepareLead(
                                            request.lead
                                        )
                                }
                            );

                        }, existingTab ? 6000 : 14000);
                    };

                if (existingTab) {

                    console.log(
                        "Reusing Existing Outlook Tab",
                        existingTab.id
                    );

                    chrome.tabs.update(
                        existingTab.id,
                        {
                            active: true
                        },
                        (tab) => {
                            startComposeFlow(
                                tab || existingTab
                            );
                        }
                    );

                    return;
                }

                chrome.tabs.create(
                    {
                        url:
                        "https://outlook.live.com/mail/0/",
                        active: false
                    },
                    (tab) => {
                        startComposeFlow(tab);
                    }
                );

            })();

        }

        if (
            request.action ===
            "emailSent"
        ) {

            chrome.storage.local.get(
                [
                    "campaign",
                    "campaignCsv",
                    "running",
                    "outlookTabId"
                ],
                async (result) => {

                    const campaign =
                        result.campaign || {
                            id: "",
                            currentRow: 1,
                            sentCount: 0,
                            pendingCount: 0,
                            status: "Ready"
                        };

                    const sentRowIndex =
                        campaign.currentRow;

                    updateStoredSheetStatus(
                        sentRowIndex,
                        "Sent"
                    );

                    campaign.currentRow =
                        campaign.currentRow + 1;

                    campaign.sentCount =
                        campaign.sentCount + 1;

                    campaign.pendingCount =
                        Math.max(
                            0,
                            campaign.pendingCount - 1
                        );

                    campaign.status =
                        "Running";

                    syncCampaignToLocalState(
                        campaign,
                        "Running"
                    );

                    console.log(
                        "Campaign Updated",
                        campaign
                    );

                    const authData =
                        await new Promise(
                            (resolve) => {

                                chrome.storage.local.get(
                                    [
                                        "licenseKey",
                                        "lastKnownGmail"
                                    ],
                                    resolve
                                );
                            }
                        );

                    const quota =
                        await logEmailToServer(
                            authData.licenseKey,
                            authData.lastKnownGmail
                        );

                    persistQuotaSnapshot(
                        authData.lastKnownGmail,
                        quota
                    );

                    if (
                        quota &&
                        (quota.remaining || 0) <= 0
                    ) {

                        console.log(
                            "Quota Reached For Outlook",
                            authData.lastKnownGmail
                        );

                        stopCampaignForQuota(
                            campaign
                        );

                        return;
                    }

                    if (
                        result.running !== true
                    ) {

                        console.log(
                            "Campaign Stopped"
                        );

                        clearOverlayCountdown();

                        return;
                    }

                    if (
                        campaign.pendingCount <= 0
                    ) {

                        campaign.status =
                            "Completed";

                        syncCampaignToLocalState(
                            campaign,
                            "Completed"
                        );

                        chrome.storage.local.set({
                            running: false
                        });

                        showOverlayForStoredOutlookTab(
                            "Campaign Completed"
                        );

                        clearOverlayCountdown();

                        console.log(
                            "Campaign Completed"
                        );

                        return;
                    }

                    const delay =
                        Math.floor(
                            Math.random() * 21
                        ) + 10;

                    showOverlayForStoredOutlookTab(
                        `Email sent. Waiting ${delay} seconds...`
                    );

                    console.log(
                        `Waiting ${delay} seconds...`
                    );

                    if (
                        result.outlookTabId
                    ) {
                        startOverlayCountdown(
                            result.outlookTabId,
                            delay
                        );
                    }

                    setTimeout(() => {

                        clearOverlayCountdown();

                        chrome.storage.local.get(
                            ["running"],
                            async (state) => {

                                if (
                                    state.running !== true
                                ) {

                                    console.log(
                                        "Campaign Stopped Before Next Lead"
                                    );

                                    clearOverlayCountdown();

                                    return;
                                }

                        const authData =
                            await new Promise(
                                (resolve) => {

                                    chrome.storage.local.get(
                                        [
                                            "licenseKey",
                                            "lastKnownGmail"
                                        ],
                                        resolve
                                    );
                                }
                            );

                        const serverQuota =
                            await canSendFromServer(
                                authData.licenseKey,
                                authData.lastKnownGmail
                            );

                        persistQuotaSnapshot(
                            authData.lastKnownGmail,
                            serverQuota
                        );

                        if (
                            serverQuota &&
                            serverQuota.allowed === false
                        ) {

                            console.log(
                                "Server Quota Blocked Next Send",
                                authData.lastKnownGmail
                            );

                            stopCampaignForQuota(
                                campaign
                            );

                            return;
                        }

                        const csv =
                            result.campaignCsv;

                        if (!csv) {

                            console.log(
                                "CSV Not Found"
                            );

                            return;
                        }

                        const parsed =
                            parseCampaignRows(
                                csv
                            );

                        const row =
                            parsed[
                                campaign.currentRow
                            ];

                        if (!row) {

                            console.log(
                                "No More Leads"
                            );

                            return;
                        }

                        const lead =
                            leadFromRow(row);

                        console.log(
                            "Loading Next Lead",
                            lead
                        );

                        console.log(
                            "Reuse Tab ID",
                            result.outlookTabId
                        );

                        chrome.tabs.get(
                            result.outlookTabId,
                            (tabInfo) => {

                                if (
                                    chrome.runtime.lastError ||
                                    !tabInfo
                                ) {

                                    console.log(
                                        "Stored Outlook Tab Missing"
                                    );

                                    return;
                                }

                                console.log(
                                    "Stored Outlook Tab Found",
                                    tabInfo.id
                                );

                                sendMessageToTab(
                                    result.outlookTabId,
                                    {
                                        action:
                                            "openCompose"
                                    }
                                );

                                console.log(
                                    "OpenCompose Sent To Existing Tab"
                                );

                                setTimeout(() => {

                                    sendMessageToTab(
                                        result.outlookTabId,
                                        {
                                            action:
                                                "fillLead",
                                            lead:
                                                lead
                                        }
                                    );

                                }, 5000);

                            }
                        );

                            }
                        );

                    }, delay * 1000);

                }
            );

        }

        if (
            request.action ===
            "emailFailed"
        ) {

            chrome.storage.local.get(
                [
                    "campaign"
                ],
                (result) => {

                    const campaign =
                        result.campaign;

                    if (!campaign) {
                        return;
                    }

                    updateStoredSheetStatus(
                        campaign.currentRow,
                        "Failed"
                    );

                    syncCampaignToLocalState(
                        campaign,
                        campaign.status || "Running"
                    );

                    console.log(
                        "Email Failed",
                        request.reason || ""
                    );

                    showOverlayForStoredOutlookTab(
                        request.reason
                            ? `Email Failed: ${request.reason}`
                            : "Email Failed"
                    );

                }
            );

        }

        if (
            request.action ===
            "pauseCampaign"
        ) {

            chrome.storage.local.get(
                [
                    "campaign",
                    "outlookTabId"
                ],
                (result) => {

                    const campaign =
                        result.campaign;

                    if (campaign) {

                        campaign.status =
                            "Stopped";

                        syncCampaignToLocalState(
                            campaign,
                            "Stopped"
                        );

                        console.log(
                            "Campaign Paused"
                        );
                    }

                    chrome.storage.local.set({
                        running: false
                    });

                    if (
                        result.outlookTabId
                    ) {

                        showOverlayForTab(
                            result.outlookTabId,
                            "Campaign Stopped"
                        );

                        clearOverlayCountdown();

                        sendMessageToTab(
                            result.outlookTabId,
                            {
                                action:
                                    "campaignStopped"
                            }
                        );
                    }
                }
            );

        }

    }
);

console.log(
    "TinyTask Mailer Background Loaded"
);








