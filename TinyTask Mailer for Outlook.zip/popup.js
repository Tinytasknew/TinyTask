﻿document.addEventListener("DOMContentLoaded", async () => {

    const activateBtn =
        document.getElementById("activateBtn");

    const statusText =
        document.getElementById("statusText");

    const gmailAddress =
        document.getElementById("gmailAddress");

    const sentToday =
        document.getElementById("sentToday");

    const remainingQuota =
        document.getElementById("remainingQuota");

    let quotaCountdownInterval =
        null;

    let currentQuotaState =
        null;

    let currentQuotaGmail =
        "";

    let quotaAlertShownFor =
        "";

    let validatedLicenseKey =
        "";

    let isLicenseValidated =
        false;

    const savedLicense =
        localStorage.getItem("ttm_license");

    const MACHINE_ID_STORAGE_KEY =
        "ttm_profile_machine_id";

    function createProfileMachineId() {
        if (
            typeof crypto !== "undefined" &&
            typeof crypto.randomUUID === "function"
        ) {
            return crypto.randomUUID();
        }

        return "ttm-profile-" + Math.random().toString(36).slice(2) + Date.now().toString(36);
    }

    function getStoredMachineId() {
        return new Promise((resolve) => {
            chrome.storage.local.get(
                MACHINE_ID_STORAGE_KEY,
                (result) => {
                    resolve(
                        String(
                            result[
                                MACHINE_ID_STORAGE_KEY
                            ] || ""
                        ).trim()
                    );
                }
            );
        });
    }

    async function getOrCreateMachineId() {
        const existingMachineId =
            await getStoredMachineId();

        if (existingMachineId) {
            return existingMachineId;
        }

        const newMachineId =
            createProfileMachineId();

        await chrome.storage.local.set({
            [MACHINE_ID_STORAGE_KEY]:
                newMachineId
        });

        return newMachineId;
    }

    const outlookHosts = [
        "outlook.office.com",
        "outlook.live.com",
        "outlook.office365.com"
    ];

    function isOutlookUrl(url) {
        return outlookHosts.some(
            (host) =>
                String(url || "").includes(host)
        );
    }

    async function getCurrentOutlookTab() {
        const tabs =
            await chrome.tabs.query({
                currentWindow: true
            });

        const preferredCurrentTab =
            tabs.find(
                (tab) =>
                    isOutlookUrl(tab.url) &&
                    tab.active === true
            );

        if (preferredCurrentTab) {
            return preferredCurrentTab;
        }

        const currentWindowOutlookTab =
            tabs.find(
                (tab) => isOutlookUrl(tab.url)
            );

        if (currentWindowOutlookTab) {
            return currentWindowOutlookTab;
        }

        return null;
    }

    async function detectOutlookAccountViaPage(
        tabId
    ) {

        try {

            const results =
                await chrome.scripting.executeScript({
                    target: {
                        tabId: tabId
                    },
                    func: () => {

                        function extractEmail(text) {
                            const match =
                                String(text || "").match(
                                    /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i
                                );
                            return match ? match[0] : "";
                        }

                        function getEmailFromElement(element) {
                            if (!element) {
                                return "";
                            }

                            return extractEmail(
                                [
                                    element.getAttribute("aria-label"),
                                    element.getAttribute("title"),
                                    element.getAttribute("data-auth"),
                                    element.getAttribute("data-email"),
                                    element.getAttribute("data-user-email"),
                                    element.textContent
                                ].filter(Boolean).join(" ")
                            );
                        }

                        const trustedSelectors = [
                            'button[aria-label*="Account manager"]',
                            'button[aria-label*="Microsoft account"]',
                            'button[aria-label*="profile"]',
                            '[role="button"][aria-label*="Account manager"]',
                            'button[data-testid="me-control"]',
                            '#O365_MainLink_Me',
                            '[aria-label*="Signed in as"]',
                            'header button[title*="@"]',
                            'aside button[title*="@"]',
                            'nav button[title*="@"]'
                        ];

                        for (const selector of trustedSelectors) {
                            const email =
                                getEmailFromElement(
                                    document.querySelector(selector)
                                );

                            if (email) {
                                return email;
                            }
                        }

                        const visibleCandidates =
                            Array.from(
                                document.querySelectorAll(
                                    "nav *, aside *, header *, [role='navigation'] *"
                                )
                            )
                                .map((element) => {
                                    const email =
                                        getEmailFromElement(element);

                                    if (!email) {
                                        return null;
                                    }

                                    const rect =
                                        element.getBoundingClientRect();

                                    if (rect.width <= 0 || rect.height <= 0) {
                                        return null;
                                    }

                                    let score = 0;

                                    if (rect.left < window.innerWidth * 0.35) {
                                        score += 4;
                                    }

                                    if (rect.top < window.innerHeight * 0.5) {
                                        score += 3;
                                    }

                                    if (/@(hotmail|outlook|live)\./i.test(email)) {
                                        score += 12;
                                    }

                                    if (element.closest("nav, aside, [role='navigation']")) {
                                        score += 5;
                                    }

                                    if (element.closest("header")) {
                                        score += 4;
                                    }

                                    if (element.closest("main, [role='main'], article")) {
                                        score -= 12;
                                    }

                                    return { email, score };
                                })
                                .filter(Boolean)
                                .sort((a, b) => b.score - a.score);

                        const preferredAccount =
                            visibleCandidates.find(
                                (candidate) =>
                                    /@(hotmail|outlook|live)\./i.test(candidate.email)
                            );

                        return preferredAccount
                            ? preferredAccount.email
                            : "";
                    }
                });

            return (
                results &&
                results[0] &&
                results[0].result
            ) || "";

        } catch (error) {
            console.error(error);
            return "";
        }
    }

    async function getOutlookAccountFromTab(
        tabId
    ) {

        if (!tabId) {
            return "";
        }

        const viaMessage =
            await new Promise(
                (resolve) => {
                    chrome.tabs.sendMessage(
                        tabId,
                        {
                            action:
                                "getOutlookAccount"
                        },
                        (response) => {

                            if (
                                chrome.runtime.lastError ||
                                !response ||
                                !response.gmail
                            ) {
                                resolve("");
                                return;
                            }

                            resolve(
                                response.gmail
                            );
                        }
                    );
                }
            );

        if (viaMessage) {
            return viaMessage;
        }

        return await detectOutlookAccountViaPage(
            tabId
        );
    }

    function setLicenseButtonState(
        isActivated
    ) {
        activateBtn.textContent =
            isActivated
                ? "Activated"
                : "Activate License";

        activateBtn.classList.toggle(
            "activated",
            isActivated
        );
    }

    function syncLicenseButtonFromInput() {
        const currentKey =
            document.getElementById(
                "licenseKey"
            ).value.trim();

        const activeKey =
            validatedLicenseKey ||
            localStorage.getItem(
                "ttm_license"
            ) || "";

        setLicenseButtonState(
            !!currentKey &&
            currentKey === activeKey
        );
    }

    function getEnteredLicenseKey() {
        return document.getElementById(
            "licenseKey"
        ).value.trim();
    }

    function getStoredLicenseKey() {
        return (
            localStorage.getItem(
                "ttm_license"
            ) || ""
        ).trim();
    }

    function clearActivatedLicenseState() {
        validatedLicenseKey = "";
        isLicenseValidated = false;

        localStorage.removeItem(
            "ttm_license"
        );

        chrome.storage.local.remove(
            "licenseKey"
        );

        setLicenseButtonState(
            false
        );
    }

    function storeActivatedLicenseKey(
        licenseKey
    ) {
        validatedLicenseKey =
            licenseKey;
        isLicenseValidated =
            true;

        localStorage.setItem(
            "ttm_license",
            licenseKey
        );

        chrome.storage.local.set({
            licenseKey:
                licenseKey
        });

        setLicenseButtonState(
            true
        );
    }

    async function validateOutlookLicense(
        licenseKey,
        options = {}
    ) {
        const {
            silent = false
        } = options;

        const normalizedKey =
            String(
                licenseKey || ""
            ).trim();

        if (!normalizedKey) {
            clearActivatedLicenseState();

            if (!silent) {
                statusText.textContent =
                    "License Required";
                alert(
                    "Please activate your Outlook license first."
                );
            }

            return false;
        }

        try {
            const machineId =
                await getOrCreateMachineId();
            const legacyMachineId =
                navigator.userAgent;

            const response =
                await fetch(
                    "https://license.tinytask.org/api/validate",
                    {
                        method: "POST",
                        headers: {
                            "Content-Type":
                                "application/json"
                        },
                        body: JSON.stringify({
                            license_key:
                                normalizedKey,
                            machine_id:
                                machineId,
                            legacy_machine_id:
                                legacyMachineId,
                            product_type:
                                "OUTLOOK"
                        })
                    }
                );

            const result =
                await response.json();

            if (result.valid) {
                storeActivatedLicenseKey(
                    normalizedKey
                );

                statusText.textContent =
                    "License Activated";

                return true;
            }

            clearActivatedLicenseState();
            statusText.textContent =
                "License Required";

            if (!silent) {
                alert(
                    result.message ||
                    "Please activate a valid Outlook license."
                );
            }

            return false;
        } catch (error) {
            console.error(error);

            if (!silent) {
                statusText.textContent =
                    "Server Error";
                alert(
                    "Unable to verify Outlook license right now."
                );
            }

            return false;
        }
    }

    async function ensureActiveOutlookLicense() {
        const candidateKey =
            getEnteredLicenseKey() ||
            validatedLicenseKey ||
            getStoredLicenseKey();

        return await validateOutlookLicense(
            candidateKey
        );
    }

    setLicenseButtonState(
        false
    );

    if (savedLicense) {
        chrome.storage.local.set({
            licenseKey:
                savedLicense
        });
    }

    const savedTotal =
        localStorage.getItem(
            "ttm_total_leads"
        );

    if (savedTotal) {

        document.getElementById(
            "totalLeads"
        ).textContent =
            savedTotal;

        document.getElementById(
            "pendingLeads"
        ).textContent =
            localStorage.getItem(
                "ttm_pending_leads"
            ) || 0;

        document.getElementById(
            "sentLeads"
        ).textContent =
            localStorage.getItem(
                "ttm_sent_leads"
            ) || 0;

        document.getElementById(
            "failedLeads"
        ).textContent =
            localStorage.getItem(
                "ttm_failed_leads"
            ) || 0;

        document.getElementById(
            "invalidEmailRows"
        ).textContent =
            localStorage.getItem(
                "ttm_invalid_email_rows"
            ) || "None";


    const savedCampaignId =
        localStorage.getItem(
            "ttm_campaign_id"
        );

    if (savedCampaignId) {

        document.getElementById(
            "campaignId"
        ).textContent =
            savedCampaignId;

        document.getElementById(
            "currentRow"
        ).textContent =
            localStorage.getItem(
                "ttm_current_row"
            ) || 1;

        document.getElementById(
            "campaignSent"
        ).textContent =
            localStorage.getItem(
                "ttm_sent_count"
            ) || 0;

        document.getElementById(
            "campaignPending"
        ).textContent =
            localStorage.getItem(
                "ttm_pending_count"
            ) || 0;

        document.getElementById(
            "campaignStatus"
        ).textContent =
            localStorage.getItem(
                "ttm_campaign_status"
            ) || "Ready";

    }

        statusText.textContent =
            localStorage.getItem(
                "ttm_campaign_status"
            ) || "Ready";

    }


    chrome.storage.local.get(
        [
            "campaign",
            "running"
        ],
        (result) => {

            const campaign =
                result.campaign;

            if (!campaign) {
                return;
            }

            syncPopupFromCampaign(
                campaign,
                result.running
            );

        }
    );

    chrome.storage.onChanged.addListener(
        (changes, areaName) => {

            if (
                areaName !== "local"
            ) {
                return;
            }

            if (
                !changes.campaign &&
                !changes.running
            ) {
                return;
            }

            chrome.storage.local.get(
                [
                    "campaign",
                    "running"
                ],
                (result) => {

                    if (!result.campaign) {
                        return;
                    }

                    syncPopupFromCampaign(
                        result.campaign,
                        result.running
                    );
                }
            );
        }
    );


    if (savedLicense) {

        document.getElementById(
            "licenseKey"
        ).value = savedLicense;

        statusText.textContent =
            "Checking License...";


    const savedSheetUrl =
        localStorage.getItem(
            "ttm_sheet_url"
        );

    if (savedSheetUrl) {

        document.getElementById(
            "sheetUrl"
        ).value =
            savedSheetUrl;

    }

    updateCampaignPlanner();
    restoreLeadPreview();


        try {
            await validateOutlookLicense(
                savedLicense,
                {
                    silent: true
                }
            );

        } catch {

            statusText.textContent =
                "Server Error";
        }
    }

    document.getElementById(
        "licenseKey"
    ).addEventListener(
        "input",
        syncLicenseButtonFromInput
    );

    try {

        const currentOutlookTab =
            await getCurrentOutlookTab();

        if (currentOutlookTab) {

            const outlookAccount =
                await getOutlookAccountFromTab(
                    currentOutlookTab.id
                );

            if (outlookAccount) {

                gmailAddress.textContent =
                    outlookAccount;

                chrome.storage.local.set({
                    lastKnownGmail:
                        outlookAccount
                });

                if (savedLicense) {
                    await fetchQuotaForOutlook(
                        outlookAccount,
                        savedLicense
                    );
                }

            } else {
                gmailAddress.textContent =
                    "Not Detected";
            }
        }

    } catch (e) {

        console.error(e);
    }


function updateCampaignPlanner() {

    const total = parseInt(localStorage.getItem("ttm_total_leads")) || 0;

    const days = parseInt(document.getElementById("targetDays").value) || 1;

    document.getElementById("emailsPerDay").textContent = Math.ceil(total / days);

    document.getElementById("gmailNeeded").textContent = Math.ceil(Math.ceil(total / days) / 50);
}

function buildGoogleSheetCsvUrl(sheetUrl) {

    if (sheetUrl.includes("output=csv")) {
        return sheetUrl;
    }

    let parsedUrl;

    try {
        parsedUrl =
            new URL(sheetUrl);
    } catch {
        throw new Error(
            "Invalid Google Sheet URL"
        );
    }

    const pathMatch =
        parsedUrl.pathname.match(
            /(\/spreadsheets(?:\/u\/\d+)?\/d\/[a-zA-Z0-9-_]+)/
        );

    if (!pathMatch) {
        throw new Error(
            "Invalid Google Sheet URL"
        );
    }

    const gid =
        parsedUrl.searchParams.get(
            "gid"
        );

    return (
        parsedUrl.origin +
        pathMatch[1] +
        "/export?format=csv" +
        (gid
            ? `&gid=${gid}`
            : "")
    );
}

function isHtmlResponse(text) {

    return /<!DOCTYPE html|<html/i.test(
        text || ""
    );
}

function waitForTabComplete(
    tabId,
    timeoutMs = 30000
) {

    return new Promise(
        (resolve, reject) => {

            let finished =
                false;

            const cleanup = () => {
                chrome.tabs.onUpdated.removeListener(
                    handleUpdated
                );
                chrome.tabs.onRemoved.removeListener(
                    handleRemoved
                );
                clearTimeout(timer);
            };

            const finish = (
                callback,
                value
            ) => {

                if (finished) {
                    return;
                }

                finished = true;
                cleanup();
                callback(value);
            };

            const handleUpdated = (
                updatedTabId,
                changeInfo
            ) => {

                if (
                    updatedTabId === tabId &&
                    changeInfo.status ===
                    "complete"
                ) {
                    finish(resolve);
                }
            };

            const handleRemoved = (
                removedTabId
            ) => {

                if (removedTabId === tabId) {
                    finish(
                        reject,
                        new Error(
                            "Google Sheet tab was closed before it finished loading."
                        )
                    );
                }
            };

            const timer =
                setTimeout(
                    () => {
                        finish(
                            reject,
                            new Error(
                                "Google Sheet took too long to load."
                            )
                        );
                    },
                    timeoutMs
                );

            chrome.tabs.onUpdated.addListener(
                handleUpdated
            );
            chrome.tabs.onRemoved.addListener(
                handleRemoved
            );

            chrome.tabs.get(
                tabId,
                (tab) => {

                    if (
                        chrome.runtime.lastError ||
                        !tab
                    ) {
                        finish(
                            reject,
                            new Error(
                                "Google Sheet tab is not available."
                            )
                        );
                        return;
                    }

                    if (
                        tab.status ===
                        "complete"
                    ) {
                        finish(resolve);
                    }
                }
            );
        }
    );
}

async function fetchGoogleSheetCsvViaTab(
    csvUrl
) {

    const tab =
        await chrome.tabs.create({
            url: csvUrl,
            active: false
        });

    try {

        await waitForTabComplete(
            tab.id
        );

        const tabInfo =
            await chrome.tabs.get(
                tab.id
            );

        if (
            tabInfo.url &&
            tabInfo.url.includes(
                "accounts.google.com"
            )
        ) {
            throw new Error(
                "Google Sheet access requires a signed-in Google account with permission to view the sheet."
            );
        }

        const results =
            await chrome.scripting.executeScript(
                {
                    target: {
                        tabId:
                            tab.id
                    },
                    func: () => {

                        return (
                            document.body &&
                            document.body.innerText
                        ) ||
                        document
                            .documentElement
                            .innerText ||
                        "";
                    }
                }
            );

        const csvText =
            results[0] &&
            results[0].result;

        if (!csvText) {
            throw new Error(
                "Unable to read Google Sheet data."
            );
        }

        if (
            isHtmlResponse(
                csvText
            )
        ) {
            throw new Error(
                "Google returned a sign-in page instead of sheet data. Please make sure the same Google account can open this sheet in the browser."
            );
        }

        return csvText;

    } finally {

        if (tab && tab.id) {
            chrome.tabs.remove(
                tab.id
            ).catch(() => {});
        }
    }
}

async function loadGoogleSheetCsv(
    sheetUrl
) {

    const csvUrl =
        buildGoogleSheetCsvUrl(
            sheetUrl
        );

    return await new Promise(
        (
            resolve,
            reject
        ) => {

            chrome.runtime.sendMessage(
                {
                    action:
                        "loadSheetCsv",
                    csvUrl:
                        csvUrl
                },
                (response) => {

                    if (
                        chrome.runtime.lastError
                    ) {
                        reject(
                            new Error(
                                chrome.runtime.lastError.message ||
                                "Unable to load sheet"
                            )
                        );
                        return;
                    }

                    if (
                        !response ||
                        response.success !== true
                    ) {
                        reject(
                            new Error(
                                response &&
                                response.error
                                    ? response.error
                                    : "Unable to load sheet"
                            )
                        );
                        return;
                    }

                    resolve(
                        response.csv
                    );
                }
            );
        }
    );
}

function restoreLeadPreview() {

    const csv = localStorage.getItem("ttm_csv");

    if (!csv) return;

    const rows = Papa.parse(csv,{
    skipEmptyLines:true
}).data;

    const leadList = document.getElementById("leadList");

    let previewHtml = "";

    for (let i = 1; i < rows.length && i <= 6; i++) {

        const cols = rows[i];

        const name = cols[0] || "";

        const email = cols[1] || "";

        previewHtml += `<div>${name}<br>${email}<hr></div>`;
    }

    leadList.innerHTML = previewHtml;

    if (rows.length > 5) {

        leadList.innerHTML +=
            '<div class="moreLeads">+' +
            (rows.length - 1 - 5) +
            ' More Leads...</div>';
    }
}

function getStatusColumnIndex(rows) {

    const header =
        rows[0] || [];

    return header.findIndex(
        column =>
            String(column || "")
                .trim()
                .toLowerCase() === "status"
    );
}

function isValidEmail(email) {

    const normalizedEmail =
        String(
            email || ""
        ).trim();

    if (!normalizedEmail) {
        return false;
    }

    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
        normalizedEmail
    );
}

function getInvalidEmailEntries(rows) {

    const invalidEntries = [];

    for (
        let i = 1;
        i < rows.length;
        i++
    ) {

        const row =
            rows[i] || [];

        const email =
            String(
                row[1] || ""
            ).trim();

        if (isValidEmail(email)) {
            continue;
        }

        invalidEntries.push({
            row: i + 1,
            email:
                email || "(blank)"
        });
    }

    return invalidEntries;
}

function formatInvalidEmailRows(invalidEntries) {

    if (
        !invalidEntries ||
        invalidEntries.length === 0
    ) {
        return "None";
    }

    return invalidEntries.map(
        (entry) =>
            `Row ${entry.row} (${entry.email})`
    ).join(", ");
}

function updateInvalidEmailReport(rows) {

    const invalidEmailRows =
        formatInvalidEmailRows(
            getInvalidEmailEntries(
                rows
            )
        );

    document.getElementById(
        "invalidEmailRows"
    ).textContent =
        invalidEmailRows;

    localStorage.setItem(
        "ttm_invalid_email_rows",
        invalidEmailRows
    );
}

function clearQuotaCountdown() {

    if (quotaCountdownInterval) {
        clearInterval(
            quotaCountdownInterval
        );
        quotaCountdownInterval =
            null;
    }
}

function persistQuotaState(
    gmail,
    quota
) {

    if (!gmail || !quota) {
        return;
    }

    chrome.storage.local.set({
        lastKnownGmail:
            gmail,
        lastQuotaState: {
            ...quota,
            gmail_account:
                gmail,
            updated_at:
                Date.now()
        }
    });
}

function applyQuotaStateToUi(
    gmail,
    quota,
    suppressAlert = false
) {

    if (!quota) {
        return null;
    }

    currentQuotaGmail =
        gmail ||
        quota.gmail_account ||
        currentQuotaGmail ||
        "";

    currentQuotaState =
        quota;

    if (currentQuotaGmail) {
        gmailAddress.textContent =
            currentQuotaGmail;
    }

    sentToday.textContent =
        quota.sent_today ?? 0;

    clearQuotaCountdown();

    if (
        (quota.remaining || 0) <= 0 &&
        (quota.quota_reset_in_seconds || 0) > 0
    ) {

        remainingQuota.textContent =
            formatQuotaCountdown(
                quota.quota_reset_in_seconds
            );

        if (
            !suppressAlert &&
            quotaAlertShownFor !== currentQuotaGmail
        ) {

            quotaAlertShownFor =
                currentQuotaGmail;

            alert(
                "Quota reached for this Outlook account. Switch accounts or wait for the timer to finish."
            );
        }

        chrome.storage.local.get(
            ["running"],
            (result) => {

                if (result.running !== true) {
                    statusText.textContent =
                        "Quota Reached - Switch Outlook";
                }
            }
        );

        let secondsLeft =
            quota.quota_reset_in_seconds;

        quotaCountdownInterval =
            setInterval(
                async () => {

                    secondsLeft =
                        Math.max(
                            secondsLeft - 1,
                            0
                        );

                    currentQuotaState = {
                        ...quota,
                        quota_reset_in_seconds:
                            secondsLeft,
                        remaining: 0
                    };

                    remainingQuota.textContent =
                        formatQuotaCountdown(
                            secondsLeft
                        );

                    if (secondsLeft > 0) {
                        return;
                    }

                    clearQuotaCountdown();

                    try {

                        const refreshedQuota =
                            await fetchQuotaForOutlook(
                                currentQuotaGmail,
                                localStorage.getItem(
                                    "ttm_license"
                                ) || "",
                                true
                            );

                        if (
                            refreshedQuota &&
                            (refreshedQuota.remaining || 0) > 0
                        ) {
                            quotaAlertShownFor =
                                "";
                        }

                    } catch (error) {

                        console.error(error);
                    }

                },
                1000
            );

        return quota;
    }

    quotaAlertShownFor = "";
    remainingQuota.textContent =
        quota.remaining ?? 0;

    chrome.storage.local.get(
        ["running"],
        (result) => {

            if (
                result.running !== true &&
                (quota.remaining || 0) > 0
            ) {
                statusText.textContent =
                    "Ready to Send";
            }
        }
    );

    return quota;
}

function formatQuotaCountdown(totalSeconds) {

    const safeSeconds =
        Math.max(
            Number(totalSeconds) || 0,
            0
        );

    const hours =
        String(
            Math.floor(safeSeconds / 3600)
        ).padStart(2, "0");

    const minutes =
        String(
            Math.floor(
                (safeSeconds % 3600) / 60
            )
        ).padStart(2, "0");

    const seconds =
        String(
            safeSeconds % 60
        ).padStart(2, "0");

    return `${hours}:${minutes}:${seconds}`;
}

async function getActiveGmailAccount() {

    const currentOutlookTab =
        await getCurrentOutlookTab();

    if (!currentOutlookTab) {
        return "";
    }

    return await getOutlookAccountFromTab(
        currentOutlookTab.id
    );
}

async function fetchQuotaForOutlook(
    gmail,
    licenseKey,
    suppressAlert = false
) {

    if (!gmail || !licenseKey) {
        return null;
    }

    const quotaResponse =
        await fetch(
            "https://license.tinytask.org/api/test-outlook",
            {
                method: "POST",
                headers: {
                    "Content-Type":
                        "application/json"
                },
                body: JSON.stringify({
                    license_key:
                        licenseKey,
                    outlook_account:
                        gmail
                })
            }
        );

    const quota =
        await quotaResponse.json();

    currentQuotaState =
        quota;
    persistQuotaState(
        gmail,
        quota
    );

    return applyQuotaStateToUi(
        gmail,
        quota,
        suppressAlert
    );
}

function syncPopupFromCampaign(campaign, isRunning) {

    if (!campaign) {
        return;
    }

    document.getElementById(
        "campaignId"
    ).textContent =
        campaign.id || "Not Started";

    document.getElementById(
        "currentRow"
    ).textContent =
        campaign.currentRow || 1;

    document.getElementById(
        "campaignSent"
    ).textContent =
        campaign.sentCount || 0;

    document.getElementById(
        "campaignPending"
    ).textContent =
        campaign.pendingCount || 0;

    document.getElementById(
        "campaignStatus"
    ).textContent =
        campaign.status || "Ready";

    const total =
        (campaign.sentCount || 0) +
        (campaign.pendingCount || 0);

    const percent =
        total > 0
            ? Math.round(
                ((campaign.sentCount || 0) / total) * 100
            )
            : 0;

    document.getElementById(
        "campaignPercent"
    ).textContent =
        percent + "%";

    document.getElementById(
        "totalLeads"
    ).textContent =
        total;

    document.getElementById(
        "pendingLeads"
    ).textContent =
        campaign.pendingCount || 0;

    document.getElementById(
        "sentLeads"
    ).textContent =
        campaign.sentCount || 0;

    localStorage.setItem(
        "ttm_current_row",
        String(
            campaign.currentRow || 1
        )
    );

    localStorage.setItem(
        "ttm_sent_count",
        String(
            campaign.sentCount || 0
        )
    );

    localStorage.setItem(
        "ttm_pending_count",
        String(
            campaign.pendingCount || 0
        )
    );

    localStorage.setItem(
        "ttm_total_leads",
        String(total)
    );

    localStorage.setItem(
        "ttm_sent_leads",
        String(
            campaign.sentCount || 0
        )
    );

    localStorage.setItem(
        "ttm_pending_leads",
        String(
            campaign.pendingCount || 0
        )
    );

    localStorage.setItem(
        "ttm_campaign_status",
        campaign.status || "Ready"
    );

    statusText.textContent =
        isRunning === true
            ? "Mailer Running"
            : campaign.status || "Ready";
}

    chrome.storage.local.get(
        [
            "lastQuotaState",
            "lastKnownGmail"
        ],
        ({ lastQuotaState, lastKnownGmail }) => {

            if (!lastQuotaState) {
                return;
            }

            applyQuotaStateToUi(
                lastKnownGmail ||
                lastQuotaState.gmail_account ||
                "",
                lastQuotaState,
                true
            );
        }
    );

    chrome.storage.onChanged.addListener(
        (changes, areaName) => {

            if (
                areaName !== "local" ||
                !changes.lastQuotaState
            ) {
                return;
            }

            const nextQuota =
                changes.lastQuotaState.newValue;

            const nextGmail =
                changes.lastKnownGmail &&
                changes.lastKnownGmail.newValue
                    ? changes.lastKnownGmail.newValue
                    : (
                        nextQuota &&
                        nextQuota.gmail_account
                    ) || currentQuotaGmail || "";

            applyQuotaStateToUi(
                nextGmail,
                nextQuota,
                true
            );
        }
    );


    activateBtn.addEventListener(
        "click",
        async () => {

            const licenseKey =
                document.getElementById(
                    "licenseKey"
                ).value.trim();

            if (!licenseKey) {
                alert(
                    "Please enter license key"
                );
                return;
            }

            const machineId =
                await getOrCreateMachineId();
            const legacyMachineId =
                navigator.userAgent;

            try {

                const response =
                    await fetch(
                        "https://license.tinytask.org/api/activate",
                        {
                            method: "POST",
                            headers: {
                                "Content-Type":
                                    "application/json"
                            },
                            body: JSON.stringify({
                                license_key:
                                    licenseKey,
                                machine_id:
                                    machineId,
                                legacy_machine_id:
                                    legacyMachineId,
                                product_type:
                                    "OUTLOOK"
                            })
                        }
                    );

                const result =
                    await response.json();

                if (result.success) {
                    storeActivatedLicenseKey(
                        licenseKey
                    );

                    statusText.textContent =
                        "License Activated";
                } else {
                    clearActivatedLicenseState();
                    setLicenseButtonState(
                        false
                    );
                }

            } catch {

                statusText.textContent =
                    "Server Error";
            }
               }
    );

    document
        .getElementById("loadSheetBtn")
        .addEventListener(
            "click",
            async () => {

                const hasActiveLicense =
                    await ensureActiveOutlookLicense();

                if (!hasActiveLicense) {
                    return;
                }

                try {

                    const sheetUrl =
                        document
                        .getElementById(
                            "sheetUrl"
                        )
                        .value
                        .trim();

                    localStorage.setItem(
                        "ttm_sheet_url",
                        sheetUrl
                    );


                    if (!sheetUrl) {

                        alert(
                            "Please enter Google Sheet URL"
                        );

                        return;
                    }

                    const csv =
                        await loadGoogleSheetCsv(
                            sheetUrl
                        );

                    const rows =
                        Papa.parse(
                            csv,
                            {
                                skipEmptyLines:true
                            }
                        ).data;

                    const total =
                        Math.max(
                            rows.length - 1,
                            0
                        );


                    // Campaign Engine
                    const campaignId =
                        localStorage.getItem(
                            "ttm_campaign_id"
                        ) || "CMP-" + Date.now();

                    localStorage.setItem(
                        "ttm_campaign_id",
                        campaignId
                    );

                    localStorage.setItem(
                        "ttm_current_row",
                        1
                    );

                    localStorage.setItem(
                        "ttm_sent_count",
                        0
                    );

                    localStorage.setItem(
                        "ttm_pending_count",
                        total
                    );

                    localStorage.setItem(
                        "ttm_campaign_status",
                        "Ready"
                    );

                    document.getElementById(
                        "campaignId"
                    ).textContent =
                        campaignId;

                    document.getElementById(
                        "currentRow"
                    ).textContent =
                        1;

                    document.getElementById(
                        "campaignSent"
                    ).textContent =
                        0;

                    document.getElementById(
                        "campaignPending"
                    ).textContent =
                        total;

                    document.getElementById(
                        "campaignStatus"
                    ).textContent =
                        "Ready";


                    const leadList =
                        document.getElementById(
                            "leadList"
                        );

                    let previewHtml = "";

                    for (
                        let i = 1;
                        i < rows.length && i <= 6;
                        i++
                    ) {

                        const cols =
                            rows[i];

                        const name =
                            cols[0] || "";

                        const email =
                            cols[1] || "";

                        previewHtml +=
                            `<div>${name}<br>${email}<hr></div>`;
                    }

                    leadList.innerHTML =
                        previewHtml;

                    if (
                        total > 5
                    ) {

                        leadList.innerHTML +=
                            '<div class="moreLeads">+' +
                            (total - 5) +
                            ' More Leads...</div>';

                    }



                    const days =
                        parseInt(
                            document
                            .getElementById(
                                "targetDays"
                            )
                            .value
                        ) || 1;

                    const emailsPerDay =
                        Math.ceil(
                            total / days
                        );

                    const gmailNeeded =
                        Math.ceil(
                            emailsPerDay / 50
                        );

                    document
                        .getElementById(
                            "emailsPerDay"
                        )
                        .textContent =
                        emailsPerDay;

                    document
                        .getElementById(
                            "gmailNeeded"
                        )
                        .textContent =
                        gmailNeeded;

                    document
                        .getElementById(
                            "totalLeads"
                        )
                        .textContent =
                        total;

                    document
                        .getElementById(
                            "pendingLeads"
                        )
                        .textContent =
                        total;

                    document
                        .getElementById(
                            "sentLeads"
                        )
                        .textContent =
                        0;

                    document
                        .getElementById(
                            "failedLeads"
                        )
                        .textContent =
                        0;

                    updateInvalidEmailReport(
                        rows
                    );

                    localStorage.setItem(
                        "ttm_total_leads",
                        total
                    );

                    localStorage.setItem(
                        "ttm_pending_leads",
                        total
                    );

                    localStorage.setItem(
                        "ttm_sent_leads",
                        0
                    );

                    localStorage.setItem(
                        "ttm_failed_leads",
                        0
                    );

                    localStorage.setItem(
                        "ttm_campaign_status",
                        "Loaded"
                    );

                    chrome.storage.local.set({
                        campaign: {
                            id: campaignId,
                            currentRow: 1,
                            sentCount: 0,
                            pendingCount: total,
                            status: "Ready"
                        },
                        campaignCsv: csv,
                        campaignLeads: rows,
                        statusColumnIndex:
                            getStatusColumnIndex(
                                rows
                            ),
                        running: false
                    });



                    localStorage.setItem(
                        "ttm_csv",
                        csv
                    );

                    alert(
                        `${total} leads loaded`
                    );

                } catch (error) {

                    console.error(
                        error
                    );

                    alert(
                        error.message ||
                        "Unable to load sheet"
                    );
                }

            }
        );


    document
        .getElementById(
            "startBtn"
        )
        .addEventListener(
            "click",
            async () => {

                const hasActiveLicense =
                    await ensureActiveOutlookLicense();

                if (!hasActiveLicense) {
                    return;
                }

                const activeLicenseKey =
                    validatedLicenseKey ||
                    getStoredLicenseKey();

                if (activeLicenseKey) {

                    chrome.storage.local.set({
                        licenseKey:
                            activeLicenseKey
                    });

                    try {

                        const activeGmail =
                            await getActiveGmailAccount();

                        if (activeGmail) {
                            await fetchQuotaForOutlook(
                                activeGmail,
                                activeLicenseKey,
                                true
                            );
                        }

                    } catch (error) {

                        console.error(error);
                    }
                }

                if (
                    currentQuotaState &&
                    (currentQuotaState.remaining || 0) <= 0 &&
                    (currentQuotaState.quota_reset_in_seconds || 0) > 0
                ) {

                    const timeLeft =
                        formatQuotaCountdown(
                            currentQuotaState.quota_reset_in_seconds
                        );

                    statusText.textContent =
                        "Quota Reached - Switch Outlook";

                    alert(
                        `Quota reached for ${currentQuotaGmail || "this Outlook account"}. Time left: ${timeLeft}`
                    );

                    return;
                }

                const csv =
                    localStorage.getItem(
                        "ttm_csv"
                    );

                if (!csv) {

                    alert(
                        "Please load a sheet first"
                    );

                    return;
                }

                const rows =
                    Papa.parse(
                        csv,
                        {
                            skipEmptyLines:true
                        }
                    ).data;

                if (rows.length < 2) {

                    alert(
                        "No leads found"
                    );

                    return;
                }

                chrome.storage.local.get(
                    [
                        "campaign"
                    ],
                    (result) => {

                        const total =
                            Math.max(
                                rows.length - 1,
                                0
                            );

                        const existingCampaign =
                            result.campaign;

                        const campaign =
                            existingCampaign
                                ? {
                                    ...existingCampaign,
                                    pendingCount:
                                        Math.max(
                                            total - (existingCampaign.sentCount || 0),
                                            0
                                        ),
                                    status:
                                        "Running"
                                }
                                : {
                                    id:
                                        localStorage.getItem(
                                            "ttm_campaign_id"
                                        ) || "CMP-" + Date.now(),
                                    currentRow: 1,
                                    sentCount: 0,
                                    pendingCount: total,
                                    status: "Running"
                                };

                        const resumeRow =
                            campaign.currentRow || 1;

                        const leadRow =
                            rows[resumeRow];

                        if (!leadRow) {

                            alert(
                                "No lead available to resume"
                            );

                            return;
                        }

                        localStorage.setItem(
                            "ttm_campaign_id",
                            campaign.id
                        );

                        statusText.textContent =
                            "Mailer Started";

                        chrome.storage.local.set({

                            campaign: campaign,

                            campaignCsv: csv,

                            campaignLeads: rows,

                            statusColumnIndex:
                                getStatusColumnIndex(
                                    rows
                                ),

                            running: true

                        }, () => {

                            syncPopupFromCampaign(
                                campaign,
                                true
                            );

                            chrome.runtime.sendMessage({

                                action: "openOutlookCompose",

                            lead: {

                                name:
                                    leadRow[0] || "",

                                email:
                                    leadRow[1] || "",

                                subject:
                                    leadRow[2] || "",

                                message:
                                    leadRow[3] === undefined ||
                                    leadRow[3] === null
                                        ? ""
                                        : String(leadRow[3])

                            }

                            });

                        });
                    }
                );

            }
        );

    document
        .getElementById(
            "stopBtn"
        )
        .addEventListener(
            "click",
            () => {

                statusText.textContent =
                    "Mailer Stopped";

                chrome.runtime.sendMessage({
                    action:
                        "pauseCampaign"
                });

            }
        );

    document
        .getElementById(
            "targetDays"
        )
        .addEventListener(
            "input",
            updateCampaignPlanner
        );

});


